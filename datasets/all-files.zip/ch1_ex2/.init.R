# open file in editor
file.edit("lab1_ex2.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)

