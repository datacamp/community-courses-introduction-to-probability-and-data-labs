# open file in editor
file.edit("lab1_ex4.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)

