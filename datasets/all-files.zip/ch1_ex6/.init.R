# open file in editor
file.edit("lab1_ex6.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)
load(url("https://assets.datacamp.com/production/repositories/302/datasets/60880e9ce4174b0c05266a5ef847b407dadf4bed/present_ex5.RData"))
