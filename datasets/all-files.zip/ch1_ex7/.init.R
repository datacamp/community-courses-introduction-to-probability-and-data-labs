# open file in editor
file.edit("lab1_ex7.2.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)
load(url("https://assets.datacamp.com/production/repositories/302/datasets/aa20c57e6278b2e1c887165548914e4c7630d62a/present_ex6.RData"))

# Knit Rmd file
#rmarkdown::render("lab1_ex7.2.Rmd")
