# open file in editor
file.edit("lab1_ex8.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)
load(url("https://assets.datacamp.com/production/repositories/302/datasets/68df966c56e035687f26596ca3d7e1a8e6f9dfe4/present_ex7.RData"))
