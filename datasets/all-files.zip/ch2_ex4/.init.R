# open file in editor
file.edit("lab2_ex4.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)