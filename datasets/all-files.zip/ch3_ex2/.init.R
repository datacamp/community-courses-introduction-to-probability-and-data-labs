# open file in editor
file.edit("lab3_ex2.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)