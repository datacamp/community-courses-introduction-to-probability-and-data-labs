# open file in editor
file.edit("lab3_ex3.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)