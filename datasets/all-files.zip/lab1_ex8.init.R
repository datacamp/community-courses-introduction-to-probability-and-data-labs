# open file in editor
file.edit("lab1_ex8.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)
load(url("http://s3.amazonaws.com/assets.datacamp.com/production/course_1161/datasets/present_ex7.RData"))
