# open file in editor
file.edit("lab3_ex5.Rmd")

# load packages
library(dplyr)
library(ggplot2)
library(statsr)